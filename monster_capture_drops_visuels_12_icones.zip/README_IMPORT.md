# Monster Capture — Visuels d'objets droppables

Lot de **12 icônes PNG**, chacune **512 × 512 px**, avec **fond transparent (RGBA)**.

Contenu strictement graphique : **aucune logique de drop, valeur de vente, ni capacité modifiée**.

## Association visuelle proposée

| Créature — Objet | Fichier |
| --- | --- |
| Elfe Vent — Plume | `icones_png_512/drop_elfe_vent_plume.png` |
| Moussado — Feuille | `icones_png_512/drop_moussado_feuille.png` |
| Hériplante — Bourgeon épineux | `icones_png_512/drop_heriplante_bourgeon_epineux.png` |
| Liane venimeuse — Fleur venimeuse | `icones_png_512/drop_liane_venimeuse_fleur_venimeuse.png` |
| Grenou — Poche aquatique | `icones_png_512/drop_grenou_poche_aquatique.png` |
| Pieuvre — Perle d’encre | `icones_png_512/drop_pieuvre_perle_encre.png` |
| Lumilo — Éclat de lumière | `icones_png_512/drop_lumilo_eclat_lumiere.png` |
| Venombre — Croc venimeux | `icones_png_512/drop_venombre_croc_venimeux.png` |
| Gori Ice — Cristal de givre | `icones_png_512/drop_gorice_cristal_givre.png` |
| Kitsune lunaire — Amulette lunaire | `icones_png_512/drop_kitsune_lunaire_amulette_lunaire.png` |
| Gemmor — Graine carnivore | `icones_png_512/drop_gemmor_graine_carnivore.png` |
| Peste noire — Spore pestilentielle | `icones_png_512/drop_peste_noire_spore_pestilentielle.png` |

## Organisation

- `icones_png_512/` : les 12 images individuelles à intégrer à la bibliothèque d'objets.
- `planches_sources/` : les 3 planches originales en pleine résolution.
- `apercu_12_icones.png` : aperçu de contrôle (fond damier pour visualiser la transparence).

Ce dossier est un lot de **visuels uniquement**. Les noms d'objets sont des propositions et doivent être rapprochés des identifiants des créatures dans la source de vérité avant tout raccordement.

Pour intégrer dans GitHub : décompresser l'archive et déposer les fichiers PNG dans le chemin retenu pour la bibliothèque d'objets, sans écraser les icônes déjà existantes.
